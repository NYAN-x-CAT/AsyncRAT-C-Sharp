﻿using Msg;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Plugin
{
    public static class Read
    {
        public static readonly string ID = Helper.HWID();
        public static void ReadData(object data)
        {
            MessageBox.Show("Reading..");
            MsgPack unpack_msgpack = new MsgPack();
            unpack_msgpack.DecodeFromBytes((byte[])data);
            switch (unpack_msgpack.ForcePathObject("Packet").AsString)
            {
                case "//":
                    {

                        break;
                    }
            }
        }
    }
}
